score = int(input("Enter the score: "))
if score>=90:
    print("A")
elif score>=70:
    print("B")
elif score>=50:
    print("C")
else:
    print("FAIL")