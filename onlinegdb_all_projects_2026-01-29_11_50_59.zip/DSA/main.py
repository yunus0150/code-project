num1= int(input("Enter a number num1:"))
num2= int(input("Enter a number num2:"))
diff= num1-num2
print("The diff is :", diff)
addition= num1+num2
print("The addition is :", addition)
prod= num1*num2
print("The prod is :", prod)
divi= num1/num2
print("The divi is :", divi)
fd= num1//num2
print("The fd is :", fd)